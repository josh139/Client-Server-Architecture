/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ict2client;

/**
 *
 * @author Gab
 */
public class ICT2Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ICT2Client client = new ICT2Client();
        client.execute();
    }

    private void execute() {
        System.out.println("[CLIENT] - Starting Test...");
        if (isConnected().equals("Connected")) {
            System.out.println("[CLIENT] - Server is connected, proceeding with the test...");

        } else {
            System.out.println("[CLIENT] - Server is NOT connected, test failed !");

        }
        System.out.println("[CLIENT] - Test Completed !");
    }

    private static String isConnected() {
        server.ICT2WebService_Service service = new server.ICT2WebService_Service();
        server.ICT2WebService port = service.getICT2WebServicePort();
        return port.isConnected();
    }
}
